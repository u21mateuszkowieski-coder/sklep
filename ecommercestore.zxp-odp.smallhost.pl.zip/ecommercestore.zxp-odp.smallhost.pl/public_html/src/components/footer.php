<footer class="site-footer">
  <p>© 2025 EcommerceStore — Twój styl. Twoje zakupy.</p>
</footer>
